package com.example.tpdevmob

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
