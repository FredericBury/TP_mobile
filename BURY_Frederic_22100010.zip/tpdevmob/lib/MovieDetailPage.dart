import 'package:flutter/material.dart';

class MovieDetailPage extends StatefulWidget {
  final Map<String, dynamic> movieDetails;

  const MovieDetailPage({super.key, required this.movieDetails});

  @override
  _MovieDetailPageState createState() => _MovieDetailPageState();
}

class _MovieDetailPageState extends State<MovieDetailPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Détails du Film')),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.network(widget.movieDetails["Poster"]),
          const SizedBox(height: 16),
          Text("Titre: ${widget.movieDetails["Title"]}"),
          Text("Année: ${widget.movieDetails["Year"]}"),

        ],
      ),
    );
  }
}
