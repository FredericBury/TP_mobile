import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'MovieDetailPage.dart';

class MovieListPage extends StatefulWidget {
  const MovieListPage({super.key});

  @override
  _MovieListPageState createState() => _MovieListPageState();
}

class _MovieListPageState extends State<MovieListPage> {
  Future<List<Map<String, dynamic>>> fetchMovies(String searchTerm) async {
    const apiKey = 'b51b3a72';
    final response = await http.get(Uri.parse('http://www.omdbapi.com/?s=$searchTerm&apikey=$apiKey'));

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      final List<dynamic> searchResults = data["Search"];
      return List<Map<String, dynamic>>.from(searchResults);
    } else {
      throw Exception('Failed to load movies');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Liste des Films')),
      body: FutureBuilder(
        future: fetchMovies("star"),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const CircularProgressIndicator();
          } else if (snapshot.hasError) {
            return Text('Erreur: ${snapshot.error}');
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(snapshot.data![index]["Title"]),
                  subtitle: Text(snapshot.data![index]["Year"]),
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      '/detail',
                      arguments: snapshot.data![index],
                    );
                  },
                );
              },
            );
          }
        },
      ),
    );
  }
}
